 var a = window.document.getElementById('area')
        function Clicar() {           
            a.innerText = 'clicou'
            a.style.background = 'red'
                    }

       function Entrar() {
           a.innerText = 'Entrou'
           a.style.background = 'green'
           console.log('teste');
       }            
       
       function Sair(){
           a.innerText = 'Saiu'
          a.style.background = 'blue'
		 
       }
	   
      
 
	   
	   